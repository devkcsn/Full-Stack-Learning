
// My own little budget app JS! (by a student)

// Class to keep all my money stuff
class MyMoneyBox {
    constructor() {
        // Try to get old data, or start fresh
        this.entries = JSON.parse(localStorage.getItem('myMoneyBox') || '[]');
    }
    add(entry) {
        this.entries.push(entry);
        this.save();
    }
    remove(id) {
        this.entries = this.entries.filter(e => e.id !== id);
        this.save();
    }
    clear() {
        this.entries = [];
        this.save();
    }
    save() {
        localStorage.setItem('myMoneyBox', JSON.stringify(this.entries));
    }
    getAll(type = 'all') {
        if (type === 'all') return this.entries;
        return this.entries.filter(e => e.kind === type);
    }
}

// Get all my elements (with new IDs)
const form = document.getElementById('spend-form');
const thingInput = document.getElementById('thing');
const rupeesInput = document.getElementById('rupees');
const kindInput = document.getElementById('kind');
const spendList = document.getElementById('spend-list');
const inMoney = document.getElementById('in-money');
const outMoney = document.getElementById('out-money');
const leftover = document.getElementById('leftover');
const clearBtn = document.getElementById('clear-everything');
const seeType = document.getElementById('see-type');

const box = new MyMoneyBox();

// Show all entries on the page
function showEntries() {
    const filter = seeType.value;
    const arr = box.getAll(filter);
    spendList.innerHTML = '';
    let got = 0, spent = 0;
    arr.forEach(e => {
        const li = document.createElement('li');
        li.className = e.kind;
        // Make the date look simple
        const date = new Date(e.time).toLocaleString();
        li.innerHTML = `<span>${date} - ${e.thing} - ₹${e.rupees} <b>(${e.kind === 'income' ? 'IN' : 'OUT'})</b></span>
            <button class="remove-btn" data-id="${e.id}">Remove</button>`;
        spendList.appendChild(li);
        if (e.kind === 'income') got += Number(e.rupees);
        else spent += Number(e.rupees);
    });
    inMoney.textContent = got;
    outMoney.textContent = spent;
    leftover.textContent = got - spent;
}

// When I add a new entry
form.addEventListener('submit', function(ev) {
    ev.preventDefault();
    const thing = thingInput.value.trim();
    const rupees = parseFloat(rupeesInput.value);
    const kind = kindInput.value;
    if (!thing || isNaN(rupees) || rupees <= 0) {
        alert('Please enter something and a positive amount!');
        return;
    }
    const entry = {
        id: Date.now().toString() + Math.random().toString(16).slice(2),
        thing,
        rupees,
        kind,
        time: new Date().toISOString()
    };
    box.add(entry);
    form.reset();
    showEntries();
});

// Remove one entry
spendList.addEventListener('click', function(ev) {
    if (ev.target.classList.contains('remove-btn')) {
        const id = ev.target.getAttribute('data-id');
        box.remove(id);
        showEntries();
    }
});

// Clear all
clearBtn.addEventListener('click', function() {
    if (confirm('Are you sure? This will delete everything!')) {
        box.clear();
        showEntries();
    }
});

// Filter
seeType.addEventListener('change', showEntries);

// Show everything when page loads
showEntries();
